#define NETHER
#include "/world_default/gbuffers_textured.vsh"
