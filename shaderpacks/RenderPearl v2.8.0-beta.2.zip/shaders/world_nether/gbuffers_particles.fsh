#define NETHER
#include "/world_default/gbuffers_particles.fsh"
